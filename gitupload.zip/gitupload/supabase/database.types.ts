export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.1"
  }
  public: {
    Tables: {
      activity_logs: {
        Row: {
          action: string
          created_at: string
          id: string
          lead_id: string
          note: string | null
          performed_by: string | null
        }
        Insert: {
          action: string
          created_at?: string
          id?: string
          lead_id: string
          note?: string | null
          performed_by?: string | null
        }
        Update: {
          action?: string
          created_at?: string
          id?: string
          lead_id?: string
          note?: string | null
          performed_by?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "activity_logs_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "activity_logs_performed_by_fkey"
            columns: ["performed_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      cart_items: {
        Row: {
          created_at: string
          id: string
          product_id: string
          product_image: string | null
          product_name: string
          product_price: number
          quantity: number
          reserved_until: string | null
          updated_at: string
          user_id: string
          variant_id: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          product_id: string
          product_image?: string | null
          product_name: string
          product_price: number
          quantity?: number
          reserved_until?: string | null
          updated_at?: string
          user_id: string
          variant_id?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          product_id?: string
          product_image?: string | null
          product_name?: string
          product_price?: number
          quantity?: number
          reserved_until?: string | null
          updated_at?: string
          user_id?: string
          variant_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "cart_items_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      categories: {
        Row: {
          created_at: string
          description: string | null
          id: string
          image: string | null
          name: string
          parent_id: string | null
          slug: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          image?: string | null
          name: string
          parent_id?: string | null
          slug: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          image?: string | null
          name?: string
          parent_id?: string | null
          slug?: string
        }
        Relationships: [
          {
            foreignKeyName: "categories_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
        ]
      }
      coupons: {
        Row: {
          code: string
          created_at: string
          description: string | null
          discount_type: string | null
          discount_value: number
          expires_at: string | null
          id: string
          min_order_value: number | null
          status: string | null
          usage_limit: number | null
          used_count: number | null
        }
        Insert: {
          code: string
          created_at?: string
          description?: string | null
          discount_type?: string | null
          discount_value: number
          expires_at?: string | null
          id?: string
          min_order_value?: number | null
          status?: string | null
          usage_limit?: number | null
          used_count?: number | null
        }
        Update: {
          code?: string
          created_at?: string
          description?: string | null
          discount_type?: string | null
          discount_value?: number
          expires_at?: string | null
          id?: string
          min_order_value?: number | null
          status?: string | null
          usage_limit?: number | null
          used_count?: number | null
        }
        Relationships: []
      }
      customer_addresses: {
        Row: {
          city: string
          country: string | null
          created_at: string
          full_name: string
          id: string
          is_default: boolean | null
          label: string | null
          phone: string
          pincode: string
          state: string
          street: string
          updated_at: string
          user_id: string
        }
        Insert: {
          city: string
          country?: string | null
          created_at?: string
          full_name: string
          id?: string
          is_default?: boolean | null
          label?: string | null
          phone: string
          pincode: string
          state: string
          street: string
          updated_at?: string
          user_id: string
        }
        Update: {
          city?: string
          country?: string | null
          created_at?: string
          full_name?: string
          id?: string
          is_default?: boolean | null
          label?: string | null
          phone?: string
          pincode?: string
          state?: string
          street?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      feedbacks: {
        Row: {
          category: string | null
          created_at: string
          customer_email: string | null
          customer_id: string | null
          customer_name: string | null
          id: string
          message: string
          priority: string | null
          responses: Json | null
          status: string | null
          subject: string
        }
        Insert: {
          category?: string | null
          created_at?: string
          customer_email?: string | null
          customer_id?: string | null
          customer_name?: string | null
          id?: string
          message: string
          priority?: string | null
          responses?: Json | null
          status?: string | null
          subject: string
        }
        Update: {
          category?: string | null
          created_at?: string
          customer_email?: string | null
          customer_id?: string | null
          customer_name?: string | null
          id?: string
          message?: string
          priority?: string | null
          responses?: Json | null
          status?: string | null
          subject?: string
        }
        Relationships: []
      }
      grn_logs: {
        Row: {
          created_at: string | null
          created_by: string | null
          id: string
          items: Json
          raw_text: string | null
          total_items: number | null
        }
        Insert: {
          created_at?: string | null
          created_by?: string | null
          id?: string
          items?: Json
          raw_text?: string | null
          total_items?: number | null
        }
        Update: {
          created_at?: string | null
          created_by?: string | null
          id?: string
          items?: Json
          raw_text?: string | null
          total_items?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "grn_logs_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      leads: {
        Row: {
          created_at: string
          email: string
          id: string
          message: string | null
          name: string
          next_follow_up_date: string | null
          phone: string | null
          source: string
          status: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          email: string
          id?: string
          message?: string | null
          name: string
          next_follow_up_date?: string | null
          phone?: string | null
          source?: string
          status?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          email?: string
          id?: string
          message?: string | null
          name?: string
          next_follow_up_date?: string | null
          phone?: string | null
          source?: string
          status?: string
          updated_at?: string
        }
        Relationships: []
      }
      newsletter_subscriptions: {
        Row: {
          email: string
          id: string
          name: string | null
          status: string | null
          subscribed_at: string
          unsubscribed_at: string | null
        }
        Insert: {
          email: string
          id?: string
          name?: string | null
          status?: string | null
          subscribed_at?: string
          unsubscribed_at?: string | null
        }
        Update: {
          email?: string
          id?: string
          name?: string | null
          status?: string | null
          subscribed_at?: string
          unsubscribed_at?: string | null
        }
        Relationships: []
      }
      order_returns: {
        Row: {
          admin_notes: string | null
          approved_by: string | null
          created_at: string
          id: string
          items: Json
          order_id: string
          reason: string
          refund_amount: number | null
          status: string | null
          updated_at: string
        }
        Insert: {
          admin_notes?: string | null
          approved_by?: string | null
          created_at?: string
          id?: string
          items: Json
          order_id: string
          reason: string
          refund_amount?: number | null
          status?: string | null
          updated_at?: string
        }
        Update: {
          admin_notes?: string | null
          approved_by?: string | null
          created_at?: string
          id?: string
          items?: Json
          order_id?: string
          reason?: string
          refund_amount?: number | null
          status?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "order_returns_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
        ]
      }
      orders: {
        Row: {
          coupon_code: string | null
          created_at: string
          customer_email: string
          customer_id: string
          customer_name: string
          customer_phone: string | null
          delivery_address: Json
          discount: number | null
          email_sent: boolean | null
          id: string
          invoice_file_id: string | null
          items: Json
          order_number: string
          paid_amount: number | null
          payment_method: string | null
          payment_status: string | null
          shipping_fee: number | null
          source: string | null
          status: string | null
          status_history: Json
          stripe_payment_intent_id: string | null
          stripe_session_id: string | null
          subtotal: number
          tax: number | null
          total: number
          updated_at: string
          user_id: string | null
        }
        Insert: {
          coupon_code?: string | null
          created_at?: string
          customer_email: string
          customer_id: string
          customer_name: string
          customer_phone?: string | null
          delivery_address: Json
          discount?: number | null
          email_sent?: boolean | null
          id?: string
          invoice_file_id?: string | null
          items?: Json
          order_number: string
          paid_amount?: number | null
          payment_method?: string | null
          payment_status?: string | null
          shipping_fee?: number | null
          source?: string | null
          status?: string | null
          status_history?: Json
          stripe_payment_intent_id?: string | null
          stripe_session_id?: string | null
          subtotal: number
          tax?: number | null
          total: number
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          coupon_code?: string | null
          created_at?: string
          customer_email?: string
          customer_id?: string
          customer_name?: string
          customer_phone?: string | null
          delivery_address?: Json
          discount?: number | null
          email_sent?: boolean | null
          id?: string
          invoice_file_id?: string | null
          items?: Json
          order_number?: string
          paid_amount?: number | null
          payment_method?: string | null
          payment_status?: string | null
          shipping_fee?: number | null
          source?: string | null
          status?: string | null
          status_history?: Json
          stripe_payment_intent_id?: string | null
          stripe_session_id?: string | null
          subtotal?: number
          tax?: number | null
          total?: number
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      product_aliases: {
        Row: {
          alias: string
          created_at: string
          created_by: string | null
          id: string
          product_id: string
          source: string
        }
        Insert: {
          alias: string
          created_at?: string
          created_by?: string | null
          id?: string
          product_id: string
          source?: string
        }
        Update: {
          alias?: string
          created_at?: string
          created_by?: string | null
          id?: string
          product_id?: string
          source?: string
        }
        Relationships: [
          {
            foreignKeyName: "product_aliases_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "product_aliases_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      product_images: {
        Row: {
          created_at: string
          display_order: number | null
          id: string
          image_url: string
          is_primary: boolean | null
          product_id: string
        }
        Insert: {
          created_at?: string
          display_order?: number | null
          id?: string
          image_url: string
          is_primary?: boolean | null
          product_id: string
        }
        Update: {
          created_at?: string
          display_order?: number | null
          id?: string
          image_url?: string
          is_primary?: boolean | null
          product_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "product_images_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      products: {
        Row: {
          application_area: string | null
          assigned_code: string | null
          availability: string | null
          brand: string | null
          category_id: string | null
          created_at: string
          description: string | null
          finish: string | null
          has_led: boolean | null
          id: string
          image: string | null
          is_clearance: boolean | null
          low_stock_threshold: number | null
          material: string | null
          name: string
          package_included: string | null
          panel_length: string | null
          panel_width: string | null
          price: number | null
          size: string | null
          slug: string
          sqm_per_box: string | null
          status: string | null
          stock: number | null
          subtitle: string | null
          thickness: string | null
          updated_at: string
        }
        Insert: {
          application_area?: string | null
          assigned_code?: string | null
          availability?: string | null
          brand?: string | null
          category_id?: string | null
          created_at?: string
          description?: string | null
          finish?: string | null
          has_led?: boolean | null
          id?: string
          image?: string | null
          is_clearance?: boolean | null
          low_stock_threshold?: number | null
          material?: string | null
          name: string
          package_included?: string | null
          panel_length?: string | null
          panel_width?: string | null
          price?: number | null
          size?: string | null
          slug: string
          sqm_per_box?: string | null
          status?: string | null
          stock?: number | null
          subtitle?: string | null
          thickness?: string | null
          updated_at?: string
        }
        Update: {
          application_area?: string | null
          assigned_code?: string | null
          availability?: string | null
          brand?: string | null
          category_id?: string | null
          created_at?: string
          description?: string | null
          finish?: string | null
          has_led?: boolean | null
          id?: string
          image?: string | null
          is_clearance?: boolean | null
          low_stock_threshold?: number | null
          material?: string | null
          name?: string
          package_included?: string | null
          panel_length?: string | null
          panel_width?: string | null
          price?: number | null
          size?: string | null
          slug?: string
          sqm_per_box?: string | null
          status?: string | null
          stock?: number | null
          subtitle?: string | null
          thickness?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "products_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          created_at: string
          email: string
          full_name: string | null
          id: string
          permissions: string[] | null
          phone: string | null
          role_id: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          email: string
          full_name?: string | null
          id: string
          permissions?: string[] | null
          phone?: string | null
          role_id: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          email?: string
          full_name?: string | null
          id?: string
          permissions?: string[] | null
          phone?: string | null
          role_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "profiles_role_id_fkey"
            columns: ["role_id"]
            isOneToOne: false
            referencedRelation: "roles"
            referencedColumns: ["id"]
          },
        ]
      }
      quotations: {
        Row: {
          created_at: string
          created_by: string | null
          customer_email: string | null
          customer_name: string
          customer_order_no: string | null
          customer_phone: string | null
          delivery_address_line1: string | null
          delivery_address_line2: string | null
          delivery_city: string | null
          delivery_collection: string
          delivery_postcode: string | null
          discount_enabled: boolean | null
          discount_percentage: number | null
          history: Json | null
          id: string
          instructions: string | null
          items: Json
          lead_id: string | null
          pdf_url: string | null
          quote_date: string
          quote_number: string
          quote_type: string
          sales_rep_name: string | null
          status: string
          subtotal: number
          total: number
          updated_at: string
          valid_until: string | null
          vat_total: number
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          customer_email?: string | null
          customer_name: string
          customer_order_no?: string | null
          customer_phone?: string | null
          delivery_address_line1?: string | null
          delivery_address_line2?: string | null
          delivery_city?: string | null
          delivery_collection?: string
          delivery_postcode?: string | null
          discount_enabled?: boolean | null
          discount_percentage?: number | null
          history?: Json | null
          id?: string
          instructions?: string | null
          items?: Json
          lead_id?: string | null
          pdf_url?: string | null
          quote_date?: string
          quote_number: string
          quote_type?: string
          sales_rep_name?: string | null
          status?: string
          subtotal?: number
          total?: number
          updated_at?: string
          valid_until?: string | null
          vat_total?: number
        }
        Update: {
          created_at?: string
          created_by?: string | null
          customer_email?: string | null
          customer_name?: string
          customer_order_no?: string | null
          customer_phone?: string | null
          delivery_address_line1?: string | null
          delivery_address_line2?: string | null
          delivery_city?: string | null
          delivery_collection?: string
          delivery_postcode?: string | null
          discount_enabled?: boolean | null
          discount_percentage?: number | null
          history?: Json | null
          id?: string
          instructions?: string | null
          items?: Json
          lead_id?: string | null
          pdf_url?: string | null
          quote_date?: string
          quote_number?: string
          quote_type?: string
          sales_rep_name?: string | null
          status?: string
          subtotal?: number
          total?: number
          updated_at?: string
          valid_until?: string | null
          vat_total?: number
        }
        Relationships: [
          {
            foreignKeyName: "quotations_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "quotations_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
        ]
      }
      recently_viewed: {
        Row: {
          id: string
          product_id: string
          user_id: string
          viewed_at: string
        }
        Insert: {
          id?: string
          product_id: string
          user_id: string
          viewed_at?: string
        }
        Update: {
          id?: string
          product_id?: string
          user_id?: string
          viewed_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "recently_viewed_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      reviews: {
        Row: {
          admin_response: string | null
          comment: string | null
          created_at: string
          customer_email: string | null
          customer_id: string | null
          customer_name: string | null
          id: string
          product_id: string | null
          product_name: string | null
          rating: number | null
          status: string | null
        }
        Insert: {
          admin_response?: string | null
          comment?: string | null
          created_at?: string
          customer_email?: string | null
          customer_id?: string | null
          customer_name?: string | null
          id?: string
          product_id?: string | null
          product_name?: string | null
          rating?: number | null
          status?: string | null
        }
        Update: {
          admin_response?: string | null
          comment?: string | null
          created_at?: string
          customer_email?: string | null
          customer_id?: string | null
          customer_name?: string | null
          id?: string
          product_id?: string | null
          product_name?: string | null
          rating?: number | null
          status?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "reviews_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "reviews_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      roles: {
        Row: {
          created_at: string
          description: string | null
          id: string
          name: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          name: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          name?: string
        }
        Relationships: []
      }
      site_settings: {
        Row: {
          currency_symbol: string | null
          customer_reviews_notifications: boolean | null
          email_on_new_orders: boolean | null
          free_shipping_threshold: number | null
          id: number
          low_stock_alerts: boolean | null
          store_address: string | null
          store_email: string | null
          store_name: string | null
          store_phone: string | null
          tax_rate: number | null
          updated_at: string | null
        }
        Insert: {
          currency_symbol?: string | null
          customer_reviews_notifications?: boolean | null
          email_on_new_orders?: boolean | null
          free_shipping_threshold?: number | null
          id?: number
          low_stock_alerts?: boolean | null
          store_address?: string | null
          store_email?: string | null
          store_name?: string | null
          store_phone?: string | null
          tax_rate?: number | null
          updated_at?: string | null
        }
        Update: {
          currency_symbol?: string | null
          customer_reviews_notifications?: boolean | null
          email_on_new_orders?: boolean | null
          free_shipping_threshold?: number | null
          id?: number
          low_stock_alerts?: boolean | null
          store_address?: string | null
          store_email?: string | null
          store_name?: string | null
          store_phone?: string | null
          tax_rate?: number | null
          updated_at?: string | null
        }
        Relationships: []
      }
      stock_audits: {
        Row: {
          created_at: string
          created_by: string | null
          id: string
          items: Json
          notes: string | null
          status: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          id?: string
          items?: Json
          notes?: string | null
          status?: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          id?: string
          items?: Json
          notes?: string | null
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "stock_audits_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      wishlist_items: {
        Row: {
          created_at: string
          id: string
          product_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          product_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          product_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "wishlist_items_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      add_quotation_history_entry: {
        Args: {
          changes: Json
          quotation_id: string
          user_id: string
          username: string
        }
        Returns: boolean
      }
      can_access_dashboard: { Args: { user_id: string }; Returns: boolean }
      generate_order_number: { Args: never; Returns: string }
      generate_quote_number: { Args: never; Returns: string }
      get_user_role: { Args: { user_id: string }; Returns: string }
      is_admin:
        | { Args: never; Returns: boolean }
        | { Args: { user_id: string }; Returns: boolean }
      is_inventory: { Args: never; Returns: boolean }
      is_staff: { Args: never; Returns: boolean }
      place_order: { Args: { p_coupon_code?: string }; Returns: string }
      set_user_role: {
        Args: { role_name: string; user_id: string }
        Returns: undefined
      }
      submit_contact_lead: {
        Args: {
          p_email: string
          p_message?: string
          p_name: string
          p_phone?: string
        }
        Returns: Json
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
